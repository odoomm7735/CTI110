# I was supposed to put a comment here
# My Last Name


# This program takes a number grade , determines average and displays letter grade for average.

# Enter grades for six modules

mod_1 = input('Enter grade for Module 1: ')
 mod_2 = input('Enter grade for Module 2: ')
mod_1 = input('Enter grade for Module 3: )
mod 4 = input('Enter grade for Module 1: ')
mod_1 = input('Enter grade for Module 5: ')
 mod_1 = input('Enter grade for Module 6: ")

# add grades entered to a list

grades = [mod_1 mod2, mod_3, mod_4, Mod_5]
# TO DO: determine lowest, highest , sum and average for grades

low = min(Grades)
high = high(grades)
sum = sum(grades)
avg =

# determine letter grade for average


if avg >= 90:
print('Your grade is: A')
else:
if average > 80:
 print('Your grade is: B')
else:

else:
print('Your grade is: F') # TO DO: finish this





