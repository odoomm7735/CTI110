# p4LAB1a_OdoomMichael.py
# July 11, 2024
# This program will use the Turtle graphics library to draw both a square and a triangle using a for loop

import turtle

# Set up the turtle
t = turtle.Turtle()
t.speed(1)  # Slow speed for better visibility

# Function to draw a square
def draw_square():
    for _ in range(4):
        t.forward(100)
        t.right(90)

# Function to draw a triangle
def draw_triangle():
    for _ in range(3):
        t.forward(100)
        t.left(120)

# Draw square
draw_square()

# Move turtle to new position for triangle
t.penup()
t.goto(150, 0)
t.pendown()

# Draw triangle
draw_triangle()

# Finish
turtle.done()
