# p4LAB1b_OdoomMichael.py
# July 11, 2024
# This program will use the Turtle graphics library to draw your initials. Replace YourInitials with your actual initials.

import turtle

# Set up the turtle
t = turtle.Turtle()
t.speed(1)  # Slow speed for better visibility
t.pensize(5)
t.color("blue")

# Function to draw the first initial (M)
def draw_first_initial():
    t.left(90)
    t.forward(100)
    t.right(135)
    t.forward(70)
    t.left(90)
    t.forward(70)
    t.right(135)
    t.forward(100)

# Function to draw the second initial "O"
def draw_second_initial():
    t.penup()
    t.goto(150, 0)
    t.pendown()
    t.circle(50)    

# # Function to draw a third initial (example: "D")
# def draw_second_initial():
#     t.penup()
#     t.goto(150, 0)
#     t.pendown()
#     t.left(90)
#     t.forward(100)
#     t.right(90)
#     t.circle(50, 180)
#     t.right(90)
#     t.forward(100)

# Draw the initials
draw_first_initial()
draw_second_initial()

# Finish
turtle.done()
